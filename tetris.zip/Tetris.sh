#!/bin/bash
if [ -d "/storage/roms/ports/tetris_port" ]; then
  GAMEDIR="/storage/roms/ports/tetris_port"
else
  GAMEDIR="/roms/ports/tetris_port"
fi
cd "$GAMEDIR"
python3 "$GAMEDIR/tetris.py"
