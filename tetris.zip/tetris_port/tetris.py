import pygame
import random

pygame.init()
pygame.joystick.init()
for i in range(pygame.joystick.get_count()):
    pygame.joystick.Joystick(i).init()

info = pygame.display.Info()
W, H = (info.current_w, info.current_h) if info.current_w > 0 else (720, 720)
screen = pygame.display.set_mode((W, H))

COLS, ROWS = 10, 20
CELL = min((H - 80) // ROWS, (W - 220) // COLS)
OFFSET_X = (W - COLS * CELL) // 2
OFFSET_Y = (H - ROWS * CELL) // 2

SHAPES = [
    [[1, 1, 1, 1]],
    [[1, 1], [1, 1]],
    [[0, 1, 0], [1, 1, 1]],
    [[1, 0, 0], [1, 1, 1]],
    [[0, 0, 1], [1, 1, 1]],
    [[0, 1, 1], [1, 1, 0]],
    [[1, 1, 0], [0, 1, 1]]
]
COLORS = [(0,240,240), (240,240,0), (160,0,240), (0,80,240), (240,160,0), (0,240,0), (240,0,0)]

grid = [[0]*COLS for _ in range(ROWS)]
score = 0
font = pygame.font.SysFont("dejavusans", 22, bold=True)

def new_piece():
    idx = random.randrange(len(SHAPES))
    return {"shape": SHAPES[idx], "color": COLORS[idx], "x": COLS//2 - 1, "y": 0}

def valid(piece, dx=0, dy=0, shape=None):
    sh = shape if shape else piece["shape"]
    for r, row in enumerate(sh):
        for c, val in enumerate(row):
            if val:
                nx, ny = piece["x"] + c + dx, piece["y"] + r + dy
                if nx < 0 or nx >= COLS or ny >= ROWS or (ny >= 0 and grid[ny][nx]):
                    return False
    return True

def rotate(shape):
    return [list(row) for row in zip(*shape[::-1])]

piece = new_piece()
clock = pygame.time.Clock()
fall_time = 0
running = True

while running:
    dt = clock.tick(30)
    fall_time += dt

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        cmd = None
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT: cmd = "L"
            elif event.key == pygame.K_RIGHT: cmd = "R"
            elif event.key == pygame.K_DOWN: cmd = "D"
            elif event.key in (pygame.K_UP, pygame.K_z): cmd = "ROT"
            elif event.key == pygame.K_ESCAPE: running = False
        elif event.type == pygame.JOYHATMOTION:
            if event.value[0] == -1: cmd = "L"
            elif event.value[0] == 1: cmd = "R"
            elif event.value[1] == -1: cmd = "D"
        elif event.type == pygame.JOYBUTTONDOWN:
            if event.button in (0, 1, 2, 3): cmd = "ROT"
            elif event.button in (6, 7, 8, 9): running = False

        if cmd == "L" and valid(piece, dx=-1): piece["x"] -= 1
        elif cmd == "R" and valid(piece, dx=1): piece["x"] += 1
        elif cmd == "D" and valid(piece, dy=1): piece["y"] += 1
        elif cmd == "ROT":
            rot = rotate(piece["shape"])
            if valid(piece, shape=rot): piece["shape"] = rot

    if fall_time > 450:
        fall_time = 0
        if valid(piece, dy=1):
            piece["y"] += 1
        else:
            for r, row in enumerate(piece["shape"]):
                for c, val in enumerate(row):
                    if val and piece["y"] + r >= 0:
                        grid[piece["y"] + r][piece["x"] + c] = piece["color"]
            new_grid = [row for row in grid if any(v == 0 for v in row)]
            cleared = ROWS - len(new_grid)
            if cleared:
                score += cleared * 100
                grid = [[0]*COLS for _ in range(cleared)] + new_grid
            piece = new_piece()
            if not valid(piece):
                grid = [[0]*COLS for _ in range(ROWS)]
                score = 0

    screen.fill((15, 15, 22))
    pygame.draw.rect(screen, (40, 44, 60), (OFFSET_X-2, OFFSET_Y-2, COLS*CELL+4, ROWS*CELL+4), 2)

    for r in range(ROWS):
        for c in range(COLS):
            if grid[r][c]:
                pygame.draw.rect(screen, grid[r][c], (OFFSET_X + c*CELL + 1, OFFSET_Y + r*CELL + 1, CELL-2, CELL-2))

    for r, row in enumerate(piece["shape"]):
        for c, val in enumerate(row):
            if val:
                pygame.draw.rect(screen, piece["color"], (OFFSET_X + (piece["x"]+c)*CELL + 1, OFFSET_Y + (piece["y"]+r)*CELL + 1, CELL-2, CELL-2))

    txt = font.render(f"TETRIS v1.0 | Pontos: {score}", True, (240, 240, 240))
    screen.blit(txt, (W//2 - txt.get_width()//2, 12))
    pygame.display.flip()
